package com.javacodegeeks.junit;

public class Calculate {

	public int sum(int var1, int var2) {
		System.out.println("Adding values: " + var1 + " + " + var2);
		return var1 + var2;
	}

}
