package com.packtpub.wflydevelopment.chapter11.exception;

public class SeatBookedException extends Exception {

    public SeatBookedException(String string) {
        super(string);
    }
}
