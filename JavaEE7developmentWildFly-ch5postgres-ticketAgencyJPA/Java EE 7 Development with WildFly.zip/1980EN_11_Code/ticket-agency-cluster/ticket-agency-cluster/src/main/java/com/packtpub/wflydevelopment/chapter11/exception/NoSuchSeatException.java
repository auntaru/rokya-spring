package com.packtpub.wflydevelopment.chapter11.exception;

public class NoSuchSeatException extends Exception {

    public NoSuchSeatException(String string) {
        super(string);
    }
}
