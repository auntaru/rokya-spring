package com.packtpub.wflydevelopment.chapter11.exception;


public class NotEnoughMoneyException extends Exception {

    public NotEnoughMoneyException(String string) {
        super(string);
    }
}
