package com.packtpub.wflydevelopment.chapter6.jms;

public enum Priority {
    LOW, HIGH
}
