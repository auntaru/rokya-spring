package com.packtpub.wflydevelopment.chapter3.exception;

public class NoSuchSeatException extends Exception {

    public NoSuchSeatException(String string) {
        super(string);
    }
}
