package com.packtpub.wflydevelopment.chapter3.exception;


public class NotEnoughMoneyException extends Exception {

    public NotEnoughMoneyException(String string) {
        super(string);
    }
}
