package com.packtpub.wflydevelopment.chapter3.boundary;

public interface TheatreInfoRemote {

    String printSeatList();
}
