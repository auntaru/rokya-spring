spring-mvc-ajax
========================

Sample Spring MVC Application demonstrating JSON AJAX requests with jQuery front-end and Spring MVC back-end.

This code is a companion to the tutorial [Easy REST-Based JSON Services with @ResponseBody](http://codetutr.com/2013/04/09/spring-mvc-easy-rest-based-json-services-with-responsebody/) on [CodeTutr.com](http://codetutr.com).