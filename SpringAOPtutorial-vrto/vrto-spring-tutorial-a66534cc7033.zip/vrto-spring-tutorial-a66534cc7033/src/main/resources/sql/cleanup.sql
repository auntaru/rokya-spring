delete from task_employee;
delete from timesheet;
delete from task;
delete from employee;
delete from manager;